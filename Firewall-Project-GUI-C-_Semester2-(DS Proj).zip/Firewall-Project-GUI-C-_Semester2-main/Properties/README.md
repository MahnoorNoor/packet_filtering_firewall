VS generated Prperties folder
